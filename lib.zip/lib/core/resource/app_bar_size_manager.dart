abstract class AppBarSizeManager{
  static double appBarSize = 99;
}