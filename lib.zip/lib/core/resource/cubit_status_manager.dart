// ignore_for_file: constant_identifier_names

//!Cubit Enums
enum CubitStatus {
  initial,
  loading,
  success,
  loadMore,
  error,
  empty
}
